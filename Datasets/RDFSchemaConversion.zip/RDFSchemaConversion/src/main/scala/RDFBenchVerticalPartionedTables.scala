import java.io.File

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

object RDFBenchVerticalPartionedTables {

  def main(args: Array[String]): Unit = {



    val conf = new SparkConf().setMaster("local").setAppName("SQLSPARK")
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    val sc = new SparkContext(conf)

    sc.setLogLevel("ERROR")

    println("Conf and SC declared...  ")

    val spark = SparkSession
      .builder()
      .master("local[*]")
      .appName("SparkConversionSingleTable")
      .getOrCreate()



    val filePathCSV=args(0)
    val filePathAVRO=args(1)
    val filePathORC=args(2)
    val filePathParquet=args(3)




    val csvFiles = new File(filePathCSV).list()





    csvFiles.foreach{verticalTableName=>

      val verticalTableName2=verticalTableName.dropRight(4)
      val RDFVerticalTableDF = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/"+verticalTableName).toDF()

      RDFVerticalTableDF.write.format("avro").save(filePathAVRO+"/"+verticalTableName2+".avro")
      RDFVerticalTableDF.write.parquet(filePathParquet+"/"+verticalTableName2+".parquet")
      RDFVerticalTableDF.write.orc(filePathORC+"/"+verticalTableName2+".orc")

      println("Vertical Table: '" +verticalTableName2+"' Has been Successfully Converted to AVRO, PARQUET and ORC !")
    }






    /*

    val RDFDFTitle = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/titles.csv").toDF()
    RDFDFTitle.write.format("com.databricks.spark.avro").save(filePathAVRO+"/title")
    RDFDFTitle.write.parquet(filePathParquet+"/title")
    RDFDFTitle.write.orc(filePathORC+"/title")


    val RDFDFIssued = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/issued.csv").toDF()
    RDFDFIssued.write.format("com.databricks.spark.avro").save(filePathAVRO+"/issued")
    RDFDFIssued.write.parquet(filePathParquet+"/issued")
    RDFDFIssued.write.orc(filePathORC+"/issued")




    val RDFDFType = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/type.csv").toDF()
    RDFDFType.write.format("com.databricks.spark.avro").save(filePathAVRO+"/type")
    RDFDFType.write.parquet(filePathParquet+"/type")
    RDFDFType.write.orc(filePathORC+"/type")





    val RDFDFCreator = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/creator.csv").toDF()
    RDFDFCreator.write.format("com.databricks.spark.avro").save(filePathAVRO+"/creator")
    RDFDFCreator.write.parquet(filePathParquet+"/creator")
    RDFDFCreator.write.orc(filePathORC+"/creator")




    val RDFDFBookTitle = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/bookTitle.csv").toDF()
    RDFDFBookTitle.write.format("com.databricks.spark.avro").save(filePathAVRO+"/bookTitle")
    RDFDFBookTitle.write.parquet(filePathParquet+"/bookTitle")
    RDFDFBookTitle.write.orc(filePathORC+"/bookTitle")




    val RDFDFPartOf = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/partOf.csv").toDF()
    RDFDFPartOf.write.format("com.databricks.spark.avro").save(filePathAVRO+"/partOf")
    RDFDFPartOf.write.parquet(filePathParquet+"/partOf")
    RDFDFPartOf.write.orc(filePathORC+"/partOf")




    val RDFDFseeAlso = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/seeAlso.csv").toDF()
    RDFDFseeAlso.write.format("com.databricks.spark.avro").save(filePathAVRO+"/seeAlso")
    RDFDFseeAlso.write.parquet(filePathParquet+"/seeAlso")
    RDFDFseeAlso.write.orc(filePathORC+"/seeAlso")





    val RDFDFPages = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/pages.csv").toDF()
    RDFDFPages.write.format("com.databricks.spark.avro").save(filePathAVRO+"/pages")
    RDFDFPages.write.parquet(filePathParquet+"/pages")
    RDFDFPages.write.orc(filePathORC+"/pages")




    val RDFDFHomePage = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/homepages.csv").toDF()
    RDFDFHomePage.write.format("com.databricks.spark.avro").save(filePathAVRO+"/homepage")
    RDFDFHomePage.write.parquet(filePathParquet+"/homepage")
    RDFDFHomePage.write.orc(filePathORC+"/homepage")



    val RDFDFAbstract = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/abstract.csv").toDF()
    RDFDFAbstract.write.format("com.databricks.spark.avro").save(filePathAVRO+"/abstract")
    RDFDFAbstract.write.parquet(filePathParquet+"/abstract")
    RDFDFAbstract.write.orc(filePathORC+"/abstract")



    val RDFDFName = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/names.csv").toDF()
    RDFDFName.write.format("com.databricks.spark.avro").save(filePathAVRO+"/name")
    RDFDFName.write.parquet(filePathParquet+"/name")
    RDFDFName.write.orc(filePathORC+"/name")



    val RDFDFJournal = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/journal.csv").toDF()
    RDFDFJournal.write.format("com.databricks.spark.avro").save(filePathAVRO+"/journal")
    RDFDFJournal.write.parquet(filePathParquet+"/journal")
    RDFDFJournal.write.orc(filePathORC+"/journal")


    val RDFDFsubClassOf = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/subClassOf.csv").toDF()
    RDFDFsubClassOf.write.format("com.databricks.spark.avro").save(filePathAVRO+"/subClassOf")
    RDFDFsubClassOf.write.parquet(filePathParquet+"/subClassOf")
    RDFDFsubClassOf.write.orc(filePathORC+"/subClassOf")


    val RDFDFEditor = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/editor.csv").toDF()
    RDFDFEditor.write.format("com.databricks.spark.avro").save(filePathAVRO+"/editor")
    RDFDFEditor.write.parquet(filePathParquet+"/editor")
    RDFDFEditor.write.orc(filePathORC+"/editor")
*/

  }

}
