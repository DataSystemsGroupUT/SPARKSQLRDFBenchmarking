import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import java.io.File

object RDFBenchProertyTables_new {

  def main(args: Array[String]): Unit = {

    val t1 = System.nanoTime

    val conf = new SparkConf().setMaster("local").setAppName("SQLSPARK")
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    val sc = new SparkContext(conf)

    sc.setLogLevel("ERROR")

    val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()
  
    /*
    val filePathCSV:String = "file:///data/Disk1/1B/CSV/PT/Venue.csv"
    val filePathAVRO:String = "file:///data/Disk1/1B/Avro/PT"
    val filePathORC:String = "file:///data/Disk1/1B/ORC/PT"
    val filePathParquet:String = "file:///data/Disk1/1B/Parquet/PT" 

    val PropertyTableName2 = "Venue"
    val RDFPropertyTableDF = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV).toDF()

    RDFPropertyTableDF.write.format("avro").save(filePathAVRO +"/"+PropertyTableName2+".avro")
    RDFPropertyTableDF.write.parquet(filePathParquet+"/"+PropertyTableName2+".parquet")
    RDFPropertyTableDF.write.orc(filePathORC+"/"+PropertyTableName2+".orc")

    println("Property Table: '" +PropertyTableName2+"' Has been Successfully Converted to AVRO, PARQUET and ORC !")
   */


    val filePathCSV:String = "file:///data/Disk1/PT500M_CSV"
    val filePathAVRO:String = "file:///data/Disk1/PT500M_AVRO"
    val filePathORC:String = "file:///data/Disk1/PT500M_ORC"
    val filePathParquet:String = "file:///data/Disk1/PT500M_PARQUET"

    //READ CSV PT FILES    
    val DocumentBooktitle= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentBooktitle.csv").toDF()
    val DocumentIsbn= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentIsbn.csv").toDF()
    val DocumentIssued= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentIssued.csv").toDF()
    val DocumentMonth= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentMonth.csv").toDF()
    val DocumentNumber= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentNumber.csv").toDF()
    val DocumentPublisher= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentPublisher.csv").toDF()
    val DocumentSeries= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentSeries.csv").toDF()
    val DocumentTitle= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentTitle.csv").toDF()
    val DocumentVolume= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/DocumentVolume.csv").toDF()
    val PublicationChapter= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/PublicationChapter.csv").toDF()
    val PublicationNote= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/PublicationNote.csv").toDF()
    val PublicationPages= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/PublicationPages.csv").toDF()
    val PublicationVenue= spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(filePathCSV+"/PublicationVenue.csv").toDF()
    println("Property Tables have been read!")
    
    // CONVERT INTO AVRO
    DocumentBooktitle.write.format("avro").save(filePathAVRO +"/DocumentBooktitle.avro")
    DocumentIsbn.write.format("avro").save(filePathAVRO +"/DocumentIsbn.avro")
    DocumentIssued.write.format("avro").save(filePathAVRO +"/DocumentIssued.avro")
    DocumentMonth.write.format("avro").save(filePathAVRO +"/DocumentMonth.avro")
    DocumentNumber.write.format("avro").save(filePathAVRO +"/DocumentNumber.avro")
    DocumentPublisher.write.format("avro").save(filePathAVRO +"/DocumentPublisher.avro")
    DocumentSeries.write.format("avro").save(filePathAVRO +"/DocumentSeries.avro")
    DocumentTitle.write.format("avro").save(filePathAVRO +"/DocumentTitle.avro")
    DocumentVolume.write.format("avro").save(filePathAVRO +"/DocumentVolume.avro")
    PublicationChapter.write.format("avro").save(filePathAVRO +"/PublicationChapter.avro")
    PublicationNote.write.format("avro").save(filePathAVRO +"/PublicationNote.avro")
    PublicationPages.write.format("avro").save(filePathAVRO +"/PublicationPages.avro")
    PublicationVenue.write.format("avro").save(filePathAVRO +"/PublicationVenue.avro")
    println("Property Tables have been converted to AVRO!")

    //CONVERT INTO PARQUET
    DocumentBooktitle.write.parquet(filePathParquet+"/DocumentBooktitle.parquet")
    DocumentIsbn.write.parquet(filePathParquet+"/DocumentIsbn.parquet")
    DocumentIssued.write.parquet(filePathParquet+"/DocumentIssued.parquet")
    DocumentMonth.write.parquet(filePathParquet+"/DocumentMonth.parquet")
    DocumentNumber.write.parquet(filePathParquet+"/DocumentNumber.parquet")
    DocumentPublisher.write.parquet(filePathParquet+"/DocumentPublisher.parquet")
    DocumentSeries.write.parquet(filePathParquet+"/DocumentSeries.parquet")
    DocumentTitle.write.parquet(filePathParquet+"/DocumentTitle.parquet")
    DocumentVolume.write.parquet(filePathParquet+"/DocumentVolume.parquet")
    PublicationChapter.write.parquet(filePathParquet+"/PublicationChapter.parquet")
    PublicationNote.write.parquet(filePathParquet+"/PublicationNote.parquet")
    PublicationPages.write.parquet(filePathParquet+"/PublicationPages.parquet")
    PublicationVenue.write.parquet(filePathParquet+"/PublicationVenue.parquet")
    println("Property Tables have been converted to PARQUET!")

    //CONVERT INTO ORC
    DocumentBooktitle.write.orc(filePathORC+"/DocumentBooktitle.orc")
    DocumentIsbn.write.orc(filePathORC+"/DocumentIsbn.orc")
    DocumentIssued.write.orc(filePathORC+"/DocumentIssued.orc")
    DocumentMonth.write.orc(filePathORC+"/DocumentMonth.orc")
    DocumentNumber.write.orc(filePathORC+"/DocumentNumber.orc")
    DocumentPublisher.write.orc(filePathORC+"/DocumentPublisher.orc")
    DocumentSeries.write.orc(filePathORC+"/DocumentSeries.orc")
    DocumentTitle.write.orc(filePathORC+"/DocumentTitle.orc")
    DocumentVolume.write.orc(filePathORC+"/DocumentVolume.orc")
    PublicationChapter.write.orc(filePathORC+"/PublicationChapter.orc")
    PublicationNote.write.orc(filePathORC+"/PublicationNote.orc")
    PublicationPages.write.orc(filePathORC+"/PublicationPages.orc")
    PublicationVenue.write.orc(filePathORC+"/PublicationVenue.orc")
    println("Property Tables have been converted to ORC!")

  }
}
