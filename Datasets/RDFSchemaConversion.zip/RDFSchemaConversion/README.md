# RDFSchemaConversion

## Schema Conversion of the native RDF Files
